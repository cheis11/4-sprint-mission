package com.sprint.mission.discodeit.entity;

public enum MessageState {
    visible,
    invisible,
    deleted;
}
