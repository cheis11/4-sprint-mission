package com.sprint.mission.discodeit.entity;

public enum ChannelState {
    activated,
    deactivated,
    deleted
}