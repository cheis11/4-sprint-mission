package com.sprint.mission.discodeit.service.jcf;

import com.sprint.mission.discodeit.service.ChannelService;
import com.sprint.mission.discodeit.service.MessageService;
import com.sprint.mission.discodeit.service.ServiceFactory;
import com.sprint.mission.discodeit.service.UserService;

public class JCFServiceFactory implements ServiceFactory {

    @Override
    public UserService createUserService() {
        return new JCFUserService();
    }

    @Override
    public ChannelService createChannelService() {
        return new JCFChannelService();
    }

    @Override
    public MessageService createMessageService() {
        return new JCFMessageService();
    }
}
