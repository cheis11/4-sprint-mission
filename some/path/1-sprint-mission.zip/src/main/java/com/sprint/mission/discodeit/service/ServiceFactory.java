package com.sprint.mission.discodeit.service;

/*
public class ServiceFactory {
    public static UserService createUserService(){
        return new JCFUserService();
    }
    public static MessageService createMessageService(){
        return new JCFMessageService();
    }
    public static ChannelService createChannelService(){
        return new JCFChannelService();
    }
}
*/
public interface ServiceFactory {
    UserService createUserService();
    ChannelService createChannelService();
    MessageService createMessageService();
}