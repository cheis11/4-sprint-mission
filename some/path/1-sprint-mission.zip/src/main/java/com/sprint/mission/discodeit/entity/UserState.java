package com.sprint.mission.discodeit.entity;

public enum UserState {
    online,
    offline,
    deleted;
}
