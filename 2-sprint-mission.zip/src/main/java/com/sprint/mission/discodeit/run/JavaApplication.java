package com.sprint.mission.discodeit.run;

import com.sprint.mission.discodeit.entity.Channel;
import com.sprint.mission.discodeit.entity.Message;
import com.sprint.mission.discodeit.entity.User;
import com.sprint.mission.discodeit.factory.ServiceFactory;
import com.sprint.mission.discodeit.service.ChannelService;
import com.sprint.mission.discodeit.service.MessageService;
import com.sprint.mission.discodeit.service.UserService;

import java.util.Optional;

public class JavaApplication {
    static User setupUser(UserService userService) {
        return userService.addUser("Alice");
    }
    static Channel setupChannel(ChannelService channelService, User user) {
        return channelService.createChannel("Acrobatic", user);
    }
    static Message setupMessage(MessageService messageService, User user, Channel channel) {
        Message message = messageService.addMessage("Hello World", user, channel);
        System.out.println("메세지 생성: " + message.getMessageId());
        return message;
    }

    public static void main(String[] args) {
        UserService fileUserService = ServiceFactory.createFileUserService();
        ChannelService fileChannelService = ServiceFactory.createFileChannelService();
        MessageService fileMessageService = ServiceFactory.createFileMessageService();

        User user = setupUser(fileUserService);
        Channel channel = setupChannel(fileChannelService, user);
        Message message = setupMessage(fileMessageService, user, channel);


        System.out.println(message.getContent());





//jcf
//        UserService jcfUserService = ServiceFactory.createJCFUserService();
//        ChannelService jcfChannelService = ServiceFactory.createJCFChannelService();
//        MessageService jcfMessageService = ServiceFactory.createJCFMessageService();
    }
}
